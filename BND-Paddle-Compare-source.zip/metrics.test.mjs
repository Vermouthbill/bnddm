import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeText, editDistance, characterErrorRate } from './metrics.mjs';
test('ignore spacing differences only', () => {
 assert.equal(normalizeText('그 래도 지금은'), '그래도지금은');
 assert.equal(editDistance('잘 잤어?', '잘 잤어?'), 0);
 assert.equal(editDistance('잘 잤어?', '살 어?'), 2);
});
test('detect emoji and timestamp contamination', () => {
 assert.ok(editDistance('굿모닝', '굿모닝 뿌') > 0);
 assert.ok(characterErrorRate('그래도 지금은 괜찮아','그래도 지금은 괜찮아 07') > 0);
});
