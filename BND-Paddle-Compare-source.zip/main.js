import { characterErrorRate } from './metrics.mjs';

const $ = id => document.getElementById(id);
const here = new URL('.', window.location.href);
const makeURL = path => new URL(path, here).href;
const samples = [
  {file: 'sample-1.png', expected: '굿모닝'},
  {file: 'sample-2.png', expected: '오늘 아침에 몇 번이나 깼어'},
  {file: 'sample-3.png', expected: '그래도 지금은 괜찮아'},
  {file: 'sample-4.png', expected: '잘 잤어?'}
];
let rows = samples.map(s=>({...s,tesseract:null,paddle:null,tm:null,pm:null,te:null,pe:null}));
let busy = false, checked = false;
let logText = [];

function log(message){
  logText.push(`[${new Date().toLocaleTimeString()}] ${message}`);
  $('log').textContent = logText.slice(-25).join('\n');
}
function status(message){$('status').textContent = message;log(message);}
function errorDetails(error){
  if (!error) return 'unknown error';
  return String(error.stack || error.message || error).slice(0, 1300);
}
function textCell(row, engine) {
  const val = row[engine], error = row[engine==='tesseract'?'te':'pe'];
  const ms = row[engine==='tesseract'?'tm':'pm'];
  if (error) return {value:'错误：'+error,color:'bad',score:'无法评分'};
  if (val===null) return {value:'尚未测试',color:'',score:'—'};
  const cer = characterErrorRate(row.expected, val);
  return {value:val||'（未识别出文字）',color:cer===0?'good':'bad',score:`字错率 ${Math.round(cer*100)}% · 用时 ${Math.round(ms||0)}ms`};
}
function render(){
  const root=$('samples');root.replaceChildren();
  rows.forEach((row,i)=>{
    const article=document.createElement('article');article.className='samplecard';
    const title=document.createElement('strong');title.textContent=`测试句 ${i+1}`;
    const img=document.createElement('img');img.className='sample';img.loading='lazy';img.src=makeURL(row.file);img.alt='完全虚构的韩语聊天测试句';
    const truth=document.createElement('div');truth.className='gt';truth.textContent='标准原文：'+row.expected;
    const pair=document.createElement('div');pair.className='pair';
    for(const [engine, label] of [['tesseract','Tesseract（旧）'],['paddle','PaddleOCR 韩文（新）']]){
      const data=textCell(row,engine);
      const box=document.createElement('div');box.className='engine';
      const name=document.createElement('strong');name.textContent=label;
      const output=document.createElement('output');output.textContent=data.value;output.className=data.color;
      const score=document.createElement('div');score.className='score';score.textContent=data.score;
      box.append(name,output,score);pair.append(box);
    }
    article.append(title,img,truth,pair);root.append(article);
  });
}

async function checkAsset(path,minSize){
  const response=await fetch(makeURL(path),{method:'HEAD',cache:'no-store'});
  if(!response.ok) throw Error(`${path} 文件 HTTP ${response.status}`);
  const len=Number(response.headers.get('content-length')||0);
  if(len && len<minSize) throw Error(`${path} 只有 ${len} 字节，可能是错误页面`);
  return len;
}
$('check').addEventListener('click',async()=>{
  if(busy)return; busy=true;$('check').disabled=true;$('run').disabled=true;checked=false;
  try{
    status('正在检查与本站同源的 OCR 模型文件……');
    const files=[['assets/det.tar',3_000_000],['assets/korean-rec.tar',9_000_000],['../ocr-assets/tesseract.min.js',10000]];
    for(const [p,n] of files){
      const len=await checkAsset(p,n);
      log(`存在：${p}${len?'（'+Math.round(len/1024/1024*10)/10+' MB）':''}`);
    }
    checked=true;$('run').disabled=false;status('静态模型文件齐全。可以开始测试，但尚未验证运行兼容性。');
  }catch(e){status('模型文件检测失败：'+errorDetails(e));}
  finally{busy=false;$('check').disabled=false;}
});

function loadTesseractScript(){
  return new Promise((resolve,reject)=>{
    if(window.Tesseract) return resolve(window.Tesseract);
    const s=document.createElement('script');s.src=makeURL('../ocr-assets/tesseract.min.js');
    s.onload=()=>window.Tesseract?resolve(window.Tesseract):reject(Error('Tesseract 加载后未注册'));
    s.onerror=()=>reject(Error('Tesseract 脚本加载失败'));
    document.head.appendChild(s);
  });
}
async function runTesseract(){
  status('开始 Tesseract 韩文测试，第一次加载语言数据较慢……');
  let worker;
  try{
    const Tesseract=await loadTesseractScript();
    worker=await Tesseract.createWorker(['kor','eng'],1,{
      workerPath:makeURL('../ocr-assets/worker.min.js'),
      corePath:makeURL('../ocr-assets/core/'),
      langPath:makeURL('../ocr-assets/lang'),
      workerBlobURL:false,
    });
    for(let i=0;i<rows.length;i++){
      const r=rows[i],begin=performance.now();
      try{
        const result=await worker.recognize(makeURL(r.file));
        r.tesseract=String(result.data?.text||'').trim();r.tm=performance.now()-begin;
      }catch(e){r.te=errorDetails(e);}
      render();status(`Tesseract：已处理 ${i+1}/${rows.length} 句。`);
    }
  }catch(e){
    rows.forEach(r=>{if(r.tesseract===null&&!r.te)r.te=errorDetails(e)});
    status('Tesseract 初始化失败：'+errorDetails(e));
  }finally{try{await worker?.terminate()}catch{};render()}
}
async function runPaddle(){
  status('正在加载 PaddleOCR.js 与韩文 ONNX 模型。首次初始化可能较慢……');
  let paddle;
  try{
    const { PaddleOCR }=await import('@paddleocr/paddleocr-js');
    paddle=await PaddleOCR.create({
      textDetectionModelName:'PP-OCRv5_mobile_det',
      textRecognitionModelName:'korean_PP-OCRv5_mobile_rec',
      textDetectionModelAsset:{url:makeURL('assets/det.tar')},
      textRecognitionModelAsset:{url:makeURL('assets/korean-rec.tar')},
      textDetectionBatchSize:1,
      textRecognitionBatchSize:1,
      worker:false,
      ortOptions:{
        backend:'wasm',
        wasmPaths:makeURL('ort/'),
        numThreads:1,
        simd:true,
      },
    });
    log('PaddleOCR 已初始化。');
    for(let i=0;i<rows.length;i++){
      const r=rows[i];const begin=performance.now();
      try{
        const response=await fetch(makeURL(r.file));
        if(!response.ok)throw Error('样本加载失败：HTTP '+response.status);
        const blob=await response.blob();
        const result=await paddle.predict(blob);
        r.paddle=Array.isArray(result?.[0]?.items) ? result[0].items.map(x=>x.text).filter(Boolean).join('\n') : '';
        r.pm=performance.now()-begin;
        if(!r.paddle)log(`警告：Paddle 第 ${i+1} 句未检测到文字。`);
      }catch(e){r.pe=errorDetails(e)}
      render();status(`PaddleOCR：已处理 ${i+1}/${rows.length} 句。`);
    }
  }catch(e){
    rows.forEach(r=>{if(r.paddle===null&&!r.pe)r.pe=errorDetails(e)});
    status('PaddleOCR 初始化失败：'+errorDetails(e));
  }finally{try{await paddle?.dispose?.()}catch{};render()}
}
$('run').addEventListener('click', async()=>{
  if(busy||!checked)return;
  busy=true;$('run').disabled=true;$('check').disabled=true;$('save').disabled=true;
  rows=samples.map(r=>({...r,tesseract:null,paddle:null,tm:null,pm:null,te:null,pe:null}));render();
  try{
    await runTesseract();
    await new Promise(resolve=>setTimeout(resolve,250));
    await runPaddle();
    const total=(key)=>rows.filter(r=>r[key]!==null&&!r[key[0]==='t'?'te':'pe']).length;
    status(`对照测试结束：Tesseract 成功运行 ${total('tesseract')}/4，PaddleOCR 成功运行 ${total('paddle')}/4。请查看每条内容和字错率。`);
    $('save').disabled=false;
  }catch(e){status('对照测试中断：'+errorDetails(e))}
  finally{busy=false;$('run').disabled=false;$('check').disabled=false;}
});
$('save').addEventListener('click',()=>{
  const data={schema:'BND_OCR_COMPARISON_0_1',sampleType:'fictional_test_lines_only',testedAt:new Date().toISOString(),device:navigator.userAgent,rows:rows.map(r=>({groundTruth:r.expected,tesseract:r.tesseract,tesseractCER:characterErrorRate(r.expected,r.tesseract||''),tesseractError:r.te,paddle:r.paddle,paddleCER:characterErrorRate(r.expected,r.paddle||''),paddleError:r.pe}))};
  const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
  a.href=url;a.download='bnd-ocr-compare-fictional.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
render();
