/** Test-only text comparison. We do not automatically correct any OCR output. */
export function normalizeText(s) {
  return String(s ?? '').normalize('NFC').replace(/\s+/gu, '').trim();
}
export function editDistance(a, b) {
  const x = Array.from(normalizeText(a)), y = Array.from(normalizeText(b));
  let previous = Array.from({length: y.length + 1}, (_,i) => i);
  for (let i = 1; i <= x.length; i++) {
    const next = [i];
    for (let j = 1; j <= y.length; j++) {
      next[j] = Math.min(
        next[j-1] + 1,
        previous[j] + 1,
        previous[j-1] + (x[i-1] === y[j-1] ? 0 : 1)
      );
    }
    previous = next;
  }
  return previous[y.length];
}
export function characterErrorRate(reference, prediction) {
  const n = Array.from(normalizeText(reference)).length;
  if (n === 0) return null;
  return editDistance(reference, prediction) / n;
}
